Hello, I’m Jednotka(v1.8)

Documentation is located in html/docs.html.
Images are not included in the main download.
