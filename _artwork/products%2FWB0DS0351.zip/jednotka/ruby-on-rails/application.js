//= require jednotka/jquery/jquery.min
//= require jednotka/jquery/jquery.mobile.custom.min
//= require jednotka/bootstrap/bootstrap.min
//= require jednotka/plugins/_plugins
//= require jednotka/jednotka
