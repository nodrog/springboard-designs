module.exports = function(rules) {
  return 'a{'+rules+'}';
}