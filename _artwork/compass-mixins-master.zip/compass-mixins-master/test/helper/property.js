module.exports = function(prop) {
  return 'a{b:'+prop+'}';
}
